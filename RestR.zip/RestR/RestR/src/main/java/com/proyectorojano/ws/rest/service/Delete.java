package com.proyectorojano.ws.rest.service;

public @interface Delete {

}
