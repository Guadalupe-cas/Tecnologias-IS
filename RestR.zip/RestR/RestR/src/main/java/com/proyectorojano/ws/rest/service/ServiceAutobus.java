package com.proyectorojano.ws.rest.service;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;



import com.proyectorojano.ws.rest.controlador.BoletoDAO;
import com.proyectorojano.ws.rest.controlador.ClienteDAO;
import com.proyectorojano.ws.rest.modelo.Boleto;
import com.proyectorojano.ws.rest.modelo.Cliente;
import com.proyectorojano.ws.rest.controlador.ViajeDAO;

import com.proyectorojano.ws.rest.modelo.Viaje;






@Path("/ProyectoRojano")
public class ServiceAutobus {
	


	@POST
	@Path("/agregarBoleto")
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_JSON})

	public static boolean  agregarBoleto ( Boleto boletoAgregar ) {
	boolean respuesta = false;
		BoletoDAO Boleto =  new  BoletoDAO ( boletoAgregar. getId () ,
				boletoAgregar.getDestino(),boletoAgregar.getFechaSalida(),boletoAgregar.getHora(),boletoAgregar.getNombreCliente(),
			boletoAgregar.getCosto(),boletoAgregar.getNumAsiento());
		if(Boleto.AgregarBoleto()){
			respuesta = true;
		} else {
			respuesta = false;
		}
		return respuesta;
		
		}
	
	@POST
	@Path("hola")
	public static String hola() {
		return "hola";
		
	}
 
 

	@Delete
	@Path("/cancelarBoleto")
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_JSON})

 	
	public boolean cancelarBoleto ( Boleto boletoCancelar ) {
		boolean respuesta = false;
	BoletoDAO Boleto =  new  BoletoDAO ( boletoCancelar. getId ());
	if(Boleto.CancelarBoleto()){
		respuesta = true;
	} else {
		respuesta = false;
	}
	return respuesta;
}

	
	@POST
	@Path("/agregarViaje")
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_JSON})


	public boolean agregarViaje (Viaje viajeAgregar ) {
		boolean respuesta = false;
 	ViajeDAO Viaje =  new  ViajeDAO ( viajeAgregar . getId(),viajeAgregar.getDestino(),viajeAgregar .getFechaSalida(), 
 			viajeAgregar.getHora(),viajeAgregar.getNombreCliente(),viajeAgregar.getCosto() , viajeAgregar .getNumAsiento());
 	if(Viaje.AgregarViaje()){
 		respuesta = true;
 	} else {
 		respuesta = false;
 		
 	}
 	return respuesta;
 	
 	}
	 
	

	@POST
	@Path("/agregarCliente")
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_JSON})


	public boolean agregarCliente ( Cliente clienteAgregar ) {
		boolean respuesta = false;
		ClienteDAO Cliente =  new  ClienteDAO ( clienteAgregar. getNombreCliente (), clienteAgregar. getApellidos(), clienteAgregar. getIdCliente());
		if(Cliente.AgregarCliente()){
			respuesta = true;
		} else {
			respuesta = false;
		}
		return respuesta;
		
		}
	 	
	public static void main(String[] args) {
		System.out.println(hola());
		Boleto boleto = new Boleto();
		boleto.setIdBoleto("100");
		boleto.setDestino("San andres tuxtla");
		boleto.setFechaSalida("15/12/2020");
		boleto.setHora("15:00");
		boleto.setNombreCliente("Vela");
		boleto.setCosto("450");
		boleto.setNumAsiento("10");
		if(agregarBoleto(boleto)) {
			System.out.println("si");
		}else {
			System.out.println("no");
		}
	}
}
