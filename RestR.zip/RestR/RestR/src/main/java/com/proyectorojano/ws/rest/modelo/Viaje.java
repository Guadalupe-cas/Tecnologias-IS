package com.proyectorojano.ws.rest.modelo;



import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Viaje {
	
	private String Id;
	private String Destino;
	private String FechaSalida;
	private String Hora;
	private String NombreCliente;
	private String Costo;
	private String NumAsiento;
	
	
	public Viaje(String id, String destino , String fechaSalida,String hora,String nombreCliente,String costo,String numAsiento) {
		
		Id = id;
		Destino = destino;
		FechaSalida = fechaSalida;
		Hora = hora;
		NombreCliente = nombreCliente;
		Costo = costo;
		NumAsiento = numAsiento;
		
		
		
		
	}



	






	public String getId() {
		return Id;
	}


	public void setIdViaje(String id) {
		Id= id;
	}








	public String getDestino() {
		return Destino;
	}





	public void setDestino(String destino) {
		Destino = destino;
	}





	public String getFechaSalida() {
		return FechaSalida;
	}





	public void setFechaSalida(String fechaSalida) {
		FechaSalida = fechaSalida;
	}





	public String getHora() {
		return Hora;
	}





	public void setHora(String hora) {
		Hora = hora;
	}


	public String getNombreCliente() {
		return NombreCliente;
	}





	public void setnombreCliente(String nombreCliente) {
		Hora = nombreCliente;
	}

	



	public String getCosto() {
		return Costo;
	}





	public void setCosto(String costo) {
		Costo = costo;
	}





	public String getNumAsiento() {
		return NumAsiento;
	}





	public void setNumAsiento(String numAsiento) {
		NumAsiento = numAsiento;
	}



}
	